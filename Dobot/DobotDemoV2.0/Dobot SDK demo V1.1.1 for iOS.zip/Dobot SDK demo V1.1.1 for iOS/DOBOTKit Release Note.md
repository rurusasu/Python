# DOBOTKit Release Note


## ver:1.1.1  date:2018-05-14
**Note:**

* 基于BLEMsgMgrKit架构重构整个SDK
* 适配Dobot消息协议的消息管理器DobotMsgMgr（继承BLEMsgMgr）
* 适配Dobot消息协议的消息DobotMsg（继承GDMsg）



## ver:1.0.1 date:2017-03-03
**Note:**

* 修改回零参数结构体
* 添加执行回零接口



## ver:1.0.0 date:2017-02-28
**Note:**	

* 蓝牙连接框架，通讯协议框架，异步等待模式
* 一些基本的API
